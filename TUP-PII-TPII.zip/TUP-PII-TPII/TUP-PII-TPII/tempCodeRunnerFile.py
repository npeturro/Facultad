    print("Ingrese un curso con distinto nombre")
                                                input("Presione enter para co